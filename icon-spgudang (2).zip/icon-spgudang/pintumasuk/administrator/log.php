<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>Log</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="../js/FileSaverExcel.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a class="active" href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <br><br>
    <?php
    if ($_SESSION['priv'] != "admin") {
        echo "<h4 align='center' style='color:red;'>MAAF, ANDA BUKAN ADMIN</h4>";
    } else {
    ?>
        <div class="container">
            <?php
            if (isset($_POST['reset'])) {
                $reset = mysqli_query($connect, "TRUNCATE TABLE log");
                $tgl = date("Y-m-d H:i:s");
                $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Clear History')");
                echo "<h4 class='text-center'>Log Berhasil Direset</h4>";
            }
            ?>
            <button class="btn btn-primary" onclick="exportTableToExcel('dataLog','log')">Export Log to Excel</button>
            <br>
            <br>
            <form action="log.php" method="POST">
                <button class="btn btn-danger" type="submit" name="reset">CLEAR HISTORY</button>
            </form>
            <br><br>
            <table id="dataLog" class="table table-bordered table-hover">
                <tr>
                    <th class="text-center">DATE</th>
                    <th class="text-center">USER</th>
                    <th class="text-center">PRIVILEGE</th>
                    <th class="text-center">ACTIVITY</th>
                </tr>
                <?php
                $query = mysqli_query($connect, "SELECT * FROM log ORDER BY tanggal DESC");
                $cek = mysqli_num_rows($query);
                if ($cek > 0) {
                    $no = 1;
                    while ($log = mysqli_fetch_array($query)) {
                ?>
                        <tr>
                            <td><?= $log['tanggal'] ?></td>
                            <td><?= $log['user'] ?></td>
                            <td><?= $log['priv'] ?></td>
                            <td><?= $log['aktivitas'] ?></td>
                        </tr>
                    <?php
                    }
                } else {
                    ?>
                    <tr>
                        <td colspan="4" class="text-center">LOG KOSONG</td>
                    </tr>
                <?php
                }
                ?>
            </table>
        </div>
    <?php
    }
    ?>
</body>

</html>
<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>Completed</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="../js/FileSaverExcel.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .kananin {
            margin-top: 1%;
            margin-left: 65%;
            position: absolute;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a class="active" href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <div class="container">
        <div class="row">
            <?php
            if (isset($_POST['deleterecord'])) {
                $kodedelete = $_POST['kode'];
                $delete1 = mysqli_query($connect, "DELETE FROM transaksi_material WHERE kode='$kodedelete'");
                $delete2 = mysqli_query($connect, "DELETE FROM transaksi_peminjam WHERE kode='$kodedelete'");
                $delete3 = mysqli_query($connect, "DELETE FROM transaksi_soiouser WHERE kode='$kodedelete'");
                $delete4 = mysqli_query($connect, "DELETE FROM transaksi_tool WHERE kode='$kodedelete'");
                $delete5 = mysqli_query($connect, "DELETE FROM transaksi_pengadaan WHERE kode='$kodedelete'");
                $tgl = date("Y-m-d H:i:s");
                $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Completed Tab - Data $kodedelete Dihapus')");
                echo "Record Berhasil Dihapus";
            }
            ?>
            <br>
            <form action="completed.php" method="POST">
                <table>
                    <tr>
                        <td>Tanggal Awal</td>
                        <td>:</td>
                        <td><input type="date" name="datestart"></td>
                    </tr>
                    <tr>
                        <td>Tanggal Akhir</td>
                        <td>:</td>
                        <td><input type="date" name="dateend"></td>
                    </tr>
                </table>
                <br>
                <select name="divisi">
                    <option selected disabled>PILIH</option>
                    <?php
                    $qmenudiv = mysqli_query($connect, "SELECT * FROM menu_divisi");
                    while ($data = mysqli_fetch_array($qmenudiv)) {
                    ?>
                        <option value="<?= $data['divisi'] ?>"><?= ucwords($data['divisi']) ?></option>
                    <?php
                    }
                    ?>
                </select>
                <br><br>
                <button name="sort" type="submit">Sort</button>
            </form>
            <br>
            <h2 class="text-center">REPORT TIKET SELESAI</h2>
            <button class="btn-primary btn-sm" onclick="exportTableToExcel('dataTiket','tiket-selesai')">Export Report Tiket to Excel</button>
            <div style="overflow:scroll; width:100%; height:500px;">
                <table border="1" id="dataTiket" class="table table-condensed">
                    <tr>
                        <th colspan="7" class="text-center">REPORT TIKET SELESAI</th>
                    </tr>
                    <?php
                    if (isset($_POST['sort'])) {
                        if (!empty($_POST['datestart']) && !empty($_POST['divisi'])) {
                            $divisi = $_POST['divisi'];
                            $datestart = $_POST['datestart'];
                            $dateend = $_POST['dateend'];
                            $query = mysqli_query($connect, "SELECT * FROM transaksi_peminjam WHERE status='COMPLETED' AND divisi='$divisi' AND tanggal BETWEEN '$datestart' AND '$dateend' ORDER BY tanggal DESC");

                            while ($data = mysqli_fetch_array($query)) {
                                $no = 1;
                                $soio = mysqli_query($connect, "SELECT * FROM transaksi_soiouser WHERE kode='$data[kode]'");
                                $tool = mysqli_query($connect, "SELECT * FROM transaksi_tool WHERE kode='$data[kode]'");
                                $material = mysqli_query($connect, "SELECT * FROM transaksi_material WHERE kode='$data[kode]'");
                                $pengadaan = mysqli_query($connect, "SELECT * FROM transaksi_pengadaan WHERE kode='$data[kode]'");
                    ?>
                                <tr>
                                    <th colspan="7" align="center"><?= $no ?></th>
                                </tr>
                                <tr>
                                    <th>Nama</th>
                                    <th>Tim</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                    <th>Kode Pinjam</th>
                                    <th>Penerima</th>
                                    <th>Aksi</th>
                                </tr>
                                <tr>
                                    <td><?= $data['nama'] ?></td>
                                    <td><?= $data['divisi'] ?></td>
                                    <td><?= $data['tanggal'] ?></td>
                                    <td><?= $data['status'] ?></td>
                                    <td><?= $data['kode'] ?></td>
                                    <td><?= $data['penerima'] ?></td>
                                    <form method="POST" action="completed.php">
                                        <input type="text" name="kode" value="<?= $data['kode'] ?>" hidden>
                                        <td>
                                            <button class="btn btn-sm btn-danger" type="submit" name="deleterecord">
                                                DELETE
                                            </button>
                                        </td>
                                    </form>
                                </tr>
                                <tr>
                                    <th>SO/IO</th>
                                    <th>User</th>
                                </tr>
                                <?php
                                while ($data1 = mysqli_fetch_array($soio)) {
                                ?>
                                    <tr>
                                        <td><?= $data1['soio'] ?></td>
                                        <td><?= $data1['user'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Tool</th>
                                </tr>
                                <tr>
                                    <?php
                                    while ($data2 = mysqli_fetch_array($tool)) {
                                    ?>
                                        <td><?= $data2['tool'] ?></td>
                                    <?php
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <th>Tipe</th>
                                    <th>Material</th>
                                    <th>Jumlah Terpakai</th>
                                </tr>
                                <?php
                                while ($data3 = mysqli_fetch_array($material)) {
                                ?>
                                    <tr>
                                        <td><?= $data3['tipe'] ?></td>
                                        <td><?= $data3['material'] ?></td>
                                        <td><?= $data3['jumlah'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Perangkat</th>
                                    <th>No SPR</th>
                                    <th>No SN</th>
                                    <th>Jumlah</th>
                                </tr>
                                <?php
                                while ($data4 = mysqli_fetch_array($pengadaan)) {
                                ?>
                                    <tr>
                                        <td><?= $data4['perangkat'] ?></td>
                                        <td><?= $data4['nospr'] ?></td>
                                        <td><?= $data4['nosn'] ?></td>
                                        <td><?= $data4['jumlah'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Note</th>
                                </tr>
                                <tr>
                                    <td><?= $data['note'] ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                </tr>
                            <?php
                                $no++;
                            }
                        } elseif (!empty($_POST['datestart']) && empty($_POST['divisi'])) {
                            $no = 1;
                            $datestart = $_POST['datestart'];
                            $dateend = $_POST['dateend'];
                            $query = mysqli_query($connect, "SELECT * FROM transaksi_peminjam WHERE status='COMPLETED' AND tanggal BETWEEN '$datestart' AND '$dateend' ORDER BY tanggal DESC");
                            while ($data = mysqli_fetch_array($query)) {
                                $soio = mysqli_query($connect, "SELECT * FROM transaksi_soiouser WHERE kode='$data[kode]'");
                                $tool = mysqli_query($connect, "SELECT * FROM transaksi_tool WHERE kode='$data[kode]'");
                                $material = mysqli_query($connect, "SELECT * FROM transaksi_material WHERE kode='$data[kode]'");
                                $pengadaan = mysqli_query($connect, "SELECT * FROM transaksi_pengadaan WHERE kode='$data[kode]'");
                            ?>
                                <tr>
                                    <th colspan="7" align="center"><?= $no ?></th>
                                </tr>
                                <tr>
                                    <th>Nama</th>
                                    <th>Tim</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                    <th>Kode Pinjam</th>
                                    <th>Penerima</th>
                                    <th>Aksi</th>
                                </tr>
                                <tr>
                                    <td><?= $data['nama'] ?></td>
                                    <td><?= $data['divisi'] ?></td>
                                    <td><?= $data['tanggal'] ?></td>
                                    <td><?= $data['status'] ?></td>
                                    <td><?= $data['kode'] ?></td>
                                    <td><?= $data['penerima'] ?></td>
                                    <form method="POST" action="completed.php">
                                        <input type="text" name="kode" value="<?= $data['kode'] ?>" hidden>
                                        <td>
                                            <button class="btn btn-sm btn-danger" type="submit" name="deleterecord">
                                                DELETE
                                            </button>
                                        </td>
                                    </form>
                                </tr>
                                <tr>
                                    <th>SO/IO</th>
                                    <th>User</th>
                                </tr>
                                <?php
                                while ($data1 = mysqli_fetch_array($soio)) {
                                ?>
                                    <tr>
                                        <td><?= $data1['soio'] ?></td>
                                        <td><?= $data1['user'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Tool</th>
                                </tr>
                                <tr>
                                    <?php
                                    while ($data2 = mysqli_fetch_array($tool)) {
                                    ?>
                                        <td><?= $data2['tool'] ?></td>
                                    <?php
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <th>Tipe</th>
                                    <th>Material</th>
                                    <th>Jumlah Terpakai</th>
                                </tr>
                                <?php
                                while ($data3 = mysqli_fetch_array($material)) {
                                ?>
                                    <tr>
                                        <td><?= $data3['tipe'] ?></td>
                                        <td><?= $data3['material'] ?></td>
                                        <td><?= $data3['jumlah'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Perangkat</th>
                                    <th>No SPR</th>
                                    <th>No SN</th>
                                    <th>Jumlah</th>
                                </tr>
                                <?php
                                while ($data4 = mysqli_fetch_array($pengadaan)) {
                                ?>
                                    <tr>
                                        <td><?= $data4['perangkat'] ?></td>
                                        <td><?= $data4['nospr'] ?></td>
                                        <td><?= $data4['nosn'] ?></td>
                                        <td><?= $data4['jumlah'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Note</th>
                                </tr>
                                <tr>
                                    <td><?= $data['note'] ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                </tr>
                            <?php
                                $no++;
                            }
                        } elseif (empty($_POST['datestart']) && !empty($_POST['divisi'])) {
                            $no = 1;
                            $divisi = $_POST['divisi'];
                            $query = mysqli_query($connect, "SELECT * FROM transaksi_peminjam WHERE status='COMPLETED' AND divisi='$divisi' ORDER BY tanggal DESC");
                            while ($data = mysqli_fetch_array($query)) {
                                $soio = mysqli_query($connect, "SELECT * FROM transaksi_soiouser WHERE kode='$data[kode]'");
                                $tool = mysqli_query($connect, "SELECT * FROM transaksi_tool WHERE kode='$data[kode]'");
                                $material = mysqli_query($connect, "SELECT * FROM transaksi_material WHERE kode='$data[kode]'");
                                $pengadaan = mysqli_query($connect, "SELECT * FROM transaksi_pengadaan WHERE kode='$data[kode]'");
                            ?>
                                <tr>
                                    <th colspan="7" align="center"><?= $no ?></th>
                                </tr>
                                <tr>
                                    <th>Nama</th>
                                    <th>Tim</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                    <th>Kode Pinjam</th>
                                    <th>Penerima</th>
                                    <th>Aksi</th>
                                </tr>
                                <tr>
                                    <td><?= $data['nama'] ?></td>
                                    <td><?= $data['divisi'] ?></td>
                                    <td><?= $data['tanggal'] ?></td>
                                    <td><?= $data['status'] ?></td>
                                    <td><?= $data['kode'] ?></td>
                                    <td><?= $data['penerima'] ?></td>
                                    <form method="POST" action="completed.php">
                                        <input type="text" name="kode" value="<?= $data['kode'] ?>" hidden>
                                        <td>
                                            <button class="btn btn-sm btn-danger" type="submit" name="deleterecord">
                                                DELETE
                                            </button>
                                        </td>
                                    </form>
                                </tr>
                                <tr>
                                    <th>SO/IO</th>
                                    <th>User</th>
                                </tr>
                                <?php
                                while ($data1 = mysqli_fetch_array($soio)) {
                                ?>
                                    <tr>
                                        <td><?= $data1['soio'] ?></td>
                                        <td><?= $data1['user'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Tool</th>
                                </tr>
                                <tr>
                                    <?php
                                    while ($data2 = mysqli_fetch_array($tool)) {
                                    ?>
                                        <td><?= $data2['tool'] ?></td>
                                    <?php
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <th>Tipe</th>
                                    <th>Material</th>
                                    <th>Jumlah Terpakai</th>
                                </tr>
                                <?php
                                while ($data3 = mysqli_fetch_array($material)) {
                                ?>
                                    <tr>
                                        <td><?= $data3['tipe'] ?></td>
                                        <td><?= $data3['material'] ?></td>
                                        <td><?= $data3['jumlah'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Perangkat</th>
                                    <th>No SPR</th>
                                    <th>No SN</th>
                                    <th>Jumlah</th>
                                </tr>
                                <?php
                                while ($data4 = mysqli_fetch_array($pengadaan)) {
                                ?>
                                    <tr>
                                        <td><?= $data4['perangkat'] ?></td>
                                        <td><?= $data4['nospr'] ?></td>
                                        <td><?= $data4['nosn'] ?></td>
                                        <td><?= $data4['jumlah'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Note</th>
                                </tr>
                                <tr>
                                    <td><?= $data['note'] ?></td>
                                </tr>
                                <tr>
                                    <td></td>
                                </tr>
                            <?php
                                $no++;
                            }
                        }
                    } else {
                        $query = mysqli_query($connect, "SELECT * FROM transaksi_peminjam WHERE status='COMPLETED' ORDER BY tanggal DESC");
                        $cek = mysqli_num_rows($query);
                        if ($cek > 0) {
                            $no = 1;
                            while ($data = mysqli_fetch_array($query)) {
                                $soio = mysqli_query($connect, "SELECT * FROM transaksi_soiouser WHERE kode='$data[kode]'");
                                $tool = mysqli_query($connect, "SELECT * FROM transaksi_tool WHERE kode='$data[kode]'");
                                $material = mysqli_query($connect, "SELECT * FROM transaksi_material WHERE kode='$data[kode]'");
                                $pengadaan = mysqli_query($connect, "SELECT * FROM transaksi_pengadaan WHERE kode='$data[kode]'");
                            ?>
                                <tr>
                                    <th colspan="7" align="center"><?= $no ?></th>
                                </tr>
                                <tr>
                                    <th>Nama</th>
                                    <th>Tim</th>
                                    <th>Tanggal</th>
                                    <th>Status</th>
                                    <th>Kode Pinjam</th>
                                    <th>Penerima</th>
                                    <th>Aksi</th>
                                </tr>
                                <tr>
                                    <td><?= $data['nama'] ?></td>
                                    <td><?= $data['divisi'] ?></td>
                                    <td><?= $data['tanggal'] ?></td>
                                    <td><?= $data['status'] ?></td>
                                    <td><?= $data['kode'] ?></td>
                                    <td><?= $data['penerima'] ?></td>
                                    <form method="POST" action="completed.php">
                                        <input type="text" name="kode" value="<?= $data['kode'] ?>" hidden>
                                        <td>
                                            <button class="btn btn-sm btn-danger" type="submit" name="deleterecord">
                                                DELETE
                                            </button>
                                        </td>
                                    </form>
                                </tr>
                                <tr>
                                    <th>SO/IO</th>
                                    <th>User</th>
                                </tr>
                                <?php
                                while ($data1 = mysqli_fetch_array($soio)) {
                                ?>
                                    <tr>
                                        <td><?= $data1['soio'] ?></td>
                                        <td><?= $data1['user'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Tool</th>
                                </tr>
                                <tr>
                                    <?php
                                    while ($data2 = mysqli_fetch_array($tool)) {
                                    ?>
                                        <td><?= $data2['tool'] ?></td>
                                    <?php
                                    }
                                    ?>
                                </tr>
                                <tr>
                                    <th>Tipe</th>
                                    <th>Material</th>
                                    <th>Jumlah Terpakai</th>
                                </tr>
                                <?php
                                while ($data3 = mysqli_fetch_array($material)) {
                                ?>
                                    <tr>
                                        <td><?= $data3['tipe'] ?></td>
                                        <td><?= $data3['material'] ?></td>
                                        <td><?= $data3['jumlah'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Perangkat</th>
                                    <th>No SPR</th>
                                    <th>No SN</th>
                                    <th>Jumlah</th>
                                </tr>
                                <?php
                                while ($data4 = mysqli_fetch_array($pengadaan)) {
                                ?>
                                    <tr>
                                        <td><?= $data4['perangkat'] ?></td>
                                        <td><?= $data4['nospr'] ?></td>
                                        <td><?= $data4['nosn'] ?></td>
                                        <td><?= $data4['jumlah'] ?></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                <tr>
                                    <th>Note</th>
                                </tr>
                                <tr>
                                    <td><?= $data['note'] ?></td>
                                </tr>
                    <?php
                                $no++;
                            }
                        } else {
                            echo "<h3>DATA TIDAK DITEMUKAN</h3>";
                        }
                    }
                    ?>
                </table>
            </div>
        </div>
        <br>
        <div class="row">
            <?php
            $cekkode = mysqli_query($connect, "SELECT kode FROM transaksi_peminjam WHERE status='COMPLETED' ORDER BY tanggal DESC");
            foreach ($cekkode as $val) {
                $query_parts[] = "'%" . mysqli_real_escape_string($connect, $val['kode']) . "%'";
            }
            $string = implode(' OR kode LIKE ', $query_parts);
            $cekmaterial = mysqli_query($connect, "SELECT material, tipe, SUM(jumlah) AS jumlah FROM transaksi_material WHERE kode LIKE {$string} GROUP BY material, tipe");
            ?>
            <h2 class="text-center">REPORT PENGGUNAAN MATERIAL</h2>
            <button class="btn-primary btn-sm" onclick="exportTableToExcel('dataMaterial','penggunaan-material')">Export Report Material to Excel</button>
            <div style="overflow:scroll; width:100%; height:500px;">
                <table id="dataMaterial" class="table table-condensed" border="1">
                    <tr>
                        <th colspan="3" class="text-center">REPORT PENGGUNAAN MATERIAL</th>
                    </tr>
                    <tr>
                        <th>Material</th>
                        <th>Tipe</th>
                        <th>Total</th>
                    </tr>
                    <?php
                    while ($cetak = mysqli_fetch_array($cekmaterial)) {
                    ?>
                        <tr>
                            <td><?= $cetak['material'] ?></td>
                            <td><?= $cetak['tipe'] ?></td>
                            <td><?= $cetak['jumlah'] ?></td>
                        </tr>
                    <?php
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>
</body>

</html>
<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
if (isset($_GET['pesan'])) {
    if ($_GET['pesan'] == 'cetak-excel') {
        // filename for download
        $filename = "data_material_" . date('Ymd') . ".xls";
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Type: application/vnd.ms-excel");
    }
}
?>
<!DOCTYPE html>
<html>

<head></head>

<body>
    <div id="container">
        <table border="1" class="table table-condensed">
            <tr>
                <th colspan="3" class="text-center">PATCHCORE SINGLEMODE</th>
            </tr>
            <tr>
                <th>Tipe</th>
                <th>Material</th>
                <th>Jumlah</th>
            </tr>
            <?php
            $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='patchcore_singlemode'");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <tr>
                    <td><?= $data['tipe'] ?></td>
                    <td><?= $data['material'] ?></td>
                    <td><?= $data['jumlah'] ?></td>
                </tr>
            <?php
            }
            ?>
        </table>

        <table border="1" class="table table-condensed">
            <tr>
                <th colspan="5" class="text-center">PATCHCORE MULTIMODE</th>
            </tr>
            <tr>
                <th>Tipe</th>
                <th>Material</th>
                <th>Jumlah</th>
            </tr>
            <?php
            $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='patchcore_multimode'");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <form action="materialmanager.php" method="POST">
                    <tr>
                        <td><?= $data['tipe'] ?></td>
                        <td><?= $data['material'] ?></td>
                        <td><?= $data['jumlah'] ?></td>
                    </tr>
                </form>
            <?php
            }
            ?>
        </table>

        <table border="1" class="table table-condensed">
            <tr>
                <th colspan="5" class="text-center">FOC</th>
            </tr>
            <tr>
                <th>Tipe</th>
                <th>Material</th>
                <th>Jumlah</th>
            </tr>
            <?php
            $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='foc'");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <form action="materialmanager.php" method="POST">
                    <tr>
                        <td><?= $data['tipe'] ?></td>
                        <td><?= $data['material'] ?></td>
                        <td><?= $data['jumlah'] ?></td>
                    </tr>
                </form>
            <?php
            }
            ?>
        </table>

        <table border="1" class="table table-condensed">
            <tr>
                <th colspan="5" class="text-center">FTTH</th>
            </tr>
            <tr>
                <th>Tipe</th>
                <th>Material</th>
                <th>Jumlah</th>
            </tr>
            <?php
            $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='ftth'");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <form action="materialmanager.php" method="POST">
                    <tr>
                        <td><?= $data['tipe'] ?></td>
                        <td><?= $data['material'] ?></td>
                        <td><?= $data['jumlah'] ?></td>
                    </tr>
                </form>
            <?php
            }
            ?>
        </table>

        <table border="1" class="table table-condensed">
            <tr>
                <th colspan="5" class="text-center">FOT</th>
            </tr>
            <tr>
                <th>Tipe</th>
                <th>Material</th>
                <th>Jumlah</th>
            </tr>
            <?php
            $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='fot'");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <form action="materialmanager.php" method="POST">
                    <tr>
                        <td><?= $data['tipe'] ?></td>
                        <td><?= $data['material'] ?></td>
                        <td><?= $data['jumlah'] ?></td>
                    </tr>
                </form>
            <?php
            }
            ?>
        </table>
    </div>
</body>

</html>
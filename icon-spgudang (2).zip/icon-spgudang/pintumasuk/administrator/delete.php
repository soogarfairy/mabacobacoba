<?php
include "../../koneksi/conn.php";

if (isset($_POST['delete'])){
    $tool = $_POST['tool'];
    $update = mysqli_query($connect, "UPDATE tool_validator SET jumlah='1' WHERE tool='$tool'");
}
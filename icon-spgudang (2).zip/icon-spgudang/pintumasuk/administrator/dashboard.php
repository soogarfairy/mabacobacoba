<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a class="active" href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
                <div class="card">
                    <div class="card-header text-center">
                        <h3>Pinjaman Aktif</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm table-responsive table-bordered">
                            <tr class="text-center">
                                <th>No</th>
                                <th>Nama</th>
                                <th>Tim</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Kode Pinjam</th>
                                <th>Aksi</th>
                            </tr>
                            <?php
                            $no = 1;
                            $query = mysqli_query($connect, "SELECT * FROM transaksi_peminjam WHERE status='ACTIVE' ORDER BY tanggal DESC");
                            $baris = mysqli_num_rows($query);
                            if ($baris > 0) {
                                while ($data = mysqli_fetch_array($query)) {
                            ?>
                                    <form action="report.php" method="POST">
                                        <tr>
                                            <td class="text-center"><?= $no; ?></td>
                                            <td><?= $data['nama']; ?></td>
                                            <td><?= $data['divisi']; ?></td>
                                            <td><?= $data['tanggal']; ?></td>
                                            <td><?= $data['status']; ?></td>
                                            <td><input type="text" name="singlesort" value="<?= $data['kode']; ?>" hidden><?= $data['kode']; ?></td>
                                            <td><button type="submit" class="btn btn-sm btn-info">Lihat Data</button></td>
                                        </tr>
                                    </form>
                            <?php
                                    $no++;
                                }
                            } else {
                                echo "<td colspan='6'><h4>TIDAK ADA DATA PINJAMAN AKTIF</h4></td>";
                            }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="row">
                    <div class="card">
                        <div class="card-header text-center">
                            Tim Peminjaman Manager
                        </div>
                        <div class="card-body">
                            <form action="action.php" method="POST" name="formTim">
                                <div class="form-group">
                                    <label for="division">Input Nama Tim :</label>
                                    <input type="text" name="divisi" id="division" class="form-control form-control-sm" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="adddivisi" class="btn btn-sm btn-primary">ADD</button>
                                </div>
                            </form>
                            <p>List Tim :</p>
                            <div style="overflow:scroll; height:320px;">
                                <table class="table table-sm table-responsive">
                                    <thead>
                                        <tr>
                                            <td>No</td>
                                            <td>Tim</td>
                                            <td colspan="2">Aksi</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $a = 1;
                                        $querytim = mysqli_query($connect, "SELECT * FROM menu_divisi");
                                        while ($data = mysqli_fetch_array($querytim)) {
                                        ?>
                                            <form action="action.php" method="POST">
                                                <tr>
                                                    <td><input type="text" name="id" value="<?= $data['id'] ?>" required hidden><?= $a ?></td>
                                                    <td><input type="text" name="divisi" class="form-control form-control-sm" value="<?= $data['divisi'] ?>" required></td>
                                                    <td><button name="updatemenudivisi" class="btn btn-sm btn-warning">UPDATE</button></td>
                                                    <td><button name="deletemenudivisi" class="btn btn-sm btn-danger">DELETE</button></td>
                                                </tr>
                                            </form>
                                        <?php
                                            $a++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="card">
                        <div class="card-header text-center">
                            Penerima Peminjaman Manager
                        </div>
                        <div class="card-body">
                            <form action="action.php" method="POST" name="formPenerima">
                                <div class="form-group">
                                    <label for="penerima">Input Nama Penerima :</label>
                                    <input type="text" name="penerima" id="penerima" class="form-control form-control-sm" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="addpenerima" class="btn btn-sm btn-primary">ADD</button>
                                </div>
                            </form>

                            <p>List Penerima :</p>
                            <div style="overflow:scroll; height:320px;">
                                <table class="table table-sm table-responsive">
                                    <thead>
                                        <tr>
                                            <td>No</td>
                                            <td>Penerima</td>
                                            <td colspan="2">Aksi</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $a = 1;
                                        $querypenerima = mysqli_query($connect, "SELECT * FROM menu_penerima");
                                        while ($data = mysqli_fetch_array($querypenerima)) {
                                        ?>
                                            <form action="action.php" method="POST">
                                                <tr>
                                                    <td><input type="text" name="id" value="<?= $data['id'] ?>" required hidden><?= $a ?></td>
                                                    <td><input type="text" name="penerima" class="form-control form-control-sm" value="<?= $data['penerima'] ?>" required></td>
                                                    <td><button name="updatemenupenerima" class="btn btn-sm btn-warning">UPDATE</button></td>
                                                    <td><button name="deletemenupenerima" class="btn btn-sm btn-danger">DELETE</button></td>
                                                </tr>
                                            </form>
                                        <?php
                                            $a++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</html>
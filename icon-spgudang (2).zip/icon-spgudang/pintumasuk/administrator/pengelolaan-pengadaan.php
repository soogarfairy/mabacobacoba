<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>Kelola Pengadaan</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="../js/FileSaverExcel.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a class="active" href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="text-center">PENGADAAN MANAGER</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <div class="panel panel-default">
                    <div class="panel-heading">TAMBAH DATA</div>
                    <div class="panel-body">
                        <form action="action.php" method="POST">
                            <div class="form-group">
                                <label>Nama Perangkat :</label>
                                <input type="text" name="perangkat" class="form-control form-control-sm" required>
                            </div>
                            <div class="form-group">
                                <label>No SPR :</label>
                                <input type="text" name="nospr" class="form-control form-control-sm" required>
                            </div>
                            <div class="form-group">
                                <label>No SN :</label>
                                <input type="text" name="nosn" class="form-control form-control-sm" required>
                            </div>
                            <div class="form-group">
                                <label>Jumlah :</label>
                                <input type="number" name="jumlah" class="form-control form-control-sm" min="1" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" name="tambah-data-pengadaan-perangkat" class="btn btn-sm btn-primary">TAMBAH</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <?php
                if (isset($_GET['pesan'])) {
                    if ($_GET['pesan'] == 'inputgagal') {
                ?>
                        <div class="alert alert-danger">
                            Input Gagal
                        </div>
                    <?php
                    }
                    if ($_GET['pesan'] == 'inputsukses') {
                    ?>
                        <div class="alert alert-success">
                            Input Sukses
                        </div>
                    <?php
                    }
                    if ($_GET['pesan'] == 'updategagal') {
                    ?>
                        <div class="alert alert-danger">
                            Update Gagal
                        </div>
                    <?php
                    }
                    if ($_GET['pesan'] == 'updatesukses') {
                    ?>
                        <div class="alert alert-success">
                            Update Sukses
                        </div>
                    <?php
                    }
                    if ($_GET['pesan'] == 'deletegagal') {
                    ?>
                        <div class="alert alert-danger">
                            Delete Gagal
                        </div>
                    <?php
                    }
                    if ($_GET['pesan'] == 'deletesukses') {
                    ?>
                        <div class="alert alert-success">
                            Delete Sukses
                        </div>
                <?php
                    }
                }
                ?>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-3">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <a href="cetak-excel-pengadaan.php?pesan=cetak-excel" class="btn btn-primary btn-sm">Export Data Pengadaan to Excel</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">DATA PENGADAAN PERANGKAT</div>
                    <div class="panel-body">
                        <div style="overflow:scroll; width:100%; height:500px;">
                            <table id="dataPengadaan" class="table table-condensed">
                                <tr>
                                    <th class="text-center">No</th>
                                    <th class="text-center">Nama Material</th>
                                    <th class="text-center">Nomor SPR</th>
                                    <th class="text-center">Serial Number</th>
                                    <th class="text-center">Jumlah</th>
                                    <th class="text-center" colspan="2">Aksi</th>
                                </tr>
                                <?php
                                $no = 1;
                                $query = mysqli_query($connect, "SELECT * FROM pengadaan_validator");
                                if (mysqli_num_rows($query) > 0) {
                                    while ($data = mysqli_fetch_array($query)) {
                                ?>
                                        <tr>
                                            <form action="action.php" method="POST">
                                                <input type="text" name="id" value="<?= $data['id'] ?>" hidden>
                                                <td><?= $no ?></td>
                                                <td><input type="text" name="perangkat" value="<?= $data['nama_perangkat'] ?>" class="form-control form-control-sm"></td>
                                                <td><input type="text" name="nospr" value="<?= $data['no_spr'] ?>" class="form-control form-control-sm"></td>
                                                <td><input type="text" name="nosn" value="<?= $data['no_sn'] ?>" class="form-control form-control-sm"></td>
                                                <td><input type="text" name="jumlah" value="<?= $data['jumlah'] ?>" class="form-control form-control-sm"></td>
                                                <td class="text-center">
                                                    <button type="submit" name="update-pengadaan-perangkat" class="btn btn-sm btn-warning">Ubah</button>
                                                </td>
                                                <td class="text-center">
                                                    <button type="submit" name="delete-pengadaan-perangkat" class="btn btn-sm btn-danger">Delete</button>
                                                </td>
                                            </form>
                                        </tr>
                                    <?php
                                        $no++;
                                    }
                                } else {
                                    ?>
                                    <tr>
                                        <td colspan="7">Belum Ada Data</td>
                                    </tr>
                                <?php
                                }

                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
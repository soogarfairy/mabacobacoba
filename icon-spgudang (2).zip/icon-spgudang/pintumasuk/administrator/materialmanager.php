<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>Dashboard</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>

    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a class="active" href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <div class="container">
        <?php
        if (isset($_POST['add'])) {
            $material = $_POST['material'];
            $jumlah = $_POST['jumlah'];
            $tipe = $_POST['tipe'];
            $tambah = mysqli_query($connect, "INSERT INTO material_validator (id,material,jumlah,tipe) VALUES ('','$material','$jumlah','$tipe')");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Material $material, Jumlah $jumlah, Tipe $tipe Ditambahkan')");
            echo "Data Berhasil Ditambahkan";
        }
        //========================================================
        ?>

        <h4>FORM TAMBAH MATERIAL</h4>
        <form action="materialmanager.php" method="POST">
            <p>Nama Material : <input name="material" type="text"></p>
            <p>Jumlah : <input name="jumlah" type="number" min="0"></p>
            <p>Tipe : <select name="tipe">
                    <option selected disabled>PILIH</option>
                    <option value="patchcore_singlemode">PatchCore SingleMode</option>
                    <option value="patchcore_multimode">PatchCore MultiMode</option>
                    <option value="foc">FOC</option>
                    <option value="ftth">FTTH</option>
                    <option value="fot">FOT</option>
                </select></p>
            <p><button class="btn btn-sm btn-primary" type="submit" name="add">Tambah Material</button></p>
        </form>
        <a href="cetak-excel-material.php?pesan=cetak-excel" class="btn btn-sm btn-primary">Export Material to Excel</a>
        <br><br>
        <h4>DATA MATERIAL</h4>
        <div style="overflow:scroll; width:100%; height:500px;">
            <table border="1" class="table table-condensed">
                <tr>
                    <th colspan="5" class="text-center">PATCHCORE SINGLEMODE</th>
                </tr>
                <tr>
                    <th>Tipe</th>
                    <th>Material</th>
                    <th>Jumlah</th>
                    <th colspan="2">Aksi</th>
                </tr>
                <?php
                $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='patchcore_singlemode'");
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <form action="materialmanager.php" method="POST">
                            <input name="id" type="text" value="<?= $data['id'] ?>" hidden>
                            <input name="tipelama" type="text" value="<?= $data['tipe'] ?>" hidden>
                            <input name="materialama" type="text" value="<?= $data['material'] ?>" hidden>
                            <input name="jumlahlama" type="text" value="<?= $data['jumlah'] ?>" hidden>
                            <td><input class="form-control form-control-sm" name="tipe" type="text" value="<?= $data['tipe'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="material" type="text" value="<?= $data['material'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="jumlah" type="text" value="<?= $data['jumlah'] ?>"></td>
                            <td><button class="btn btn-sm btn-warning" name="updatepsm" type="submit">Ubah</button></td>
                            <td><button class="btn btn-sm btn-danger" name="deletepsm" type="submit">Delete</button></td>
                        </form>
                    </tr>
                <?php
                }
                ?>
            </table>
        </div>
        <br><br>
        <?php
        if (isset($_POST['updatepsm'])) {
            $tipelama = $_POST['tipelama'];
            $materialama = $_POST['materialama'];
            $jumlahlama = $_POST['jumlahlama'];
            $updateid = $_POST['id'];
            $updatetipe = $_POST['tipe'];
            $updatematerial = $_POST['material'];
            $updatejumlah = $_POST['jumlah'];
            $update = mysqli_query($connect, "UPDATE material_validator SET tipe='$updatetipe', material='$updatematerial', jumlah='$updatejumlah' WHERE id='$updateid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Update Material $materialama Menjadi $updatematerial, Tipe $tipelama Menjadi $updatetipe Dan Jumlah $jumlahlama Menjadi $updatejumlah')");
            echo "Data Berhasil Diupdate";
        }
        if (isset($_POST['deletepsm'])) {
            $materialama = $_POST['materialama'];
            $deleteid = $_POST['id'];
            $delete = mysqli_query($connect, "DELETE FROM material_validator WHERE id='$deleteid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Material $materialama Dihapus')");
            echo "Data Berhasil Dihapus";
        }
        ?>


        <div style="overflow:scroll; width:100%; height:500px;">
            <table border="1" class="table table-condensed">
                <tr>
                    <th colspan="5" class="text-center">PATCHCORE MULTIMODE</th>
                </tr>
                <tr>
                    <th>Tipe</th>
                    <th>Material</th>
                    <th>Jumlah</th>
                    <th colspan="2">Aksi</th>
                </tr>
                <?php
                $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='patchcore_multimode'");
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <form action="materialmanager.php" method="POST">
                        <tr>
                            <input name="id" type="text" value="<?= $data['id'] ?>" hidden>
                            <input name="tipelama" type="text" value="<?= $data['tipe'] ?>" hidden>
                            <input name="materialama" type="text" value="<?= $data['material'] ?>" hidden>
                            <input name="jumlahlama" type="text" value="<?= $data['jumlah'] ?>" hidden>
                            <td><input class="form-control form-control-sm" name="tipe" type="text" value="<?= $data['tipe'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="material" type="text" value="<?= $data['material'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="jumlah" type="text" value="<?= $data['jumlah'] ?>"></td>
                            <td><button class="btn btn-sm btn-warning" name="updatepmm" type="submit">Ubah</button></td>
                            <td><button class="btn btn-sm btn-danger" name="deletepmm" type="submit">Delete</button></td>
                        </tr>
                    </form>
                <?php
                }
                ?>
            </table>
        </div>
        <br><br>

        <?php
        if (isset($_POST['updatepmm'])) {
            $tipelama = $_POST['tipelama'];
            $materialama = $_POST['materialama'];
            $jumlahlama = $_POST['jumlahlama'];
            $updatejumlah = $_POST['jumlah'];
            $updateid = $_POST['id'];
            $updatetipe = $_POST['tipe'];
            $updatematerial = $_POST['material'];
            $update = mysqli_query($connect, "UPDATE material_validator SET tipe='$updatetipe', material='$updatematerial', jumlah='$updatejumlah' WHERE id='$updateid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Update Material $materialama Menjadi $updatematerial, Tipe $tipelama Menjadi $updatetipe Dan Jumlah $jumlahlama Menjadi $updatejumlah')");
            echo "Data Berhasil Diupdate";
        }
        if (isset($_POST['deletepmm'])) {
            $materialama = $_POST['materialama'];
            $deleteid = $_POST['id'];
            $delete = mysqli_query($connect, "DELETE FROM material_validator WHERE id='$deleteid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Material $materialama Dihapus')");
            echo "Data Berhasil Dihapus";
        }
        ?>


        <div style="overflow:scroll; width:100%; height:500px;">
            <table border="1" class="table table-condensed">
                <tr>
                    <th colspan="5" class="text-center">FOC</th>
                </tr>
                <tr>
                    <th>Tipe</th>
                    <th>Material</th>
                    <th>Jumlah</th>
                    <th colspan="2">Aksi</th>
                </tr>
                <?php
                $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='foc'");
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <form action="materialmanager.php" method="POST">
                        <tr>
                            <input name="id" type="text" value="<?= $data['id'] ?>" hidden>
                            <input name="tipelama" type="text" value="<?= $data['tipe'] ?>" hidden>
                            <input name="materialama" type="text" value="<?= $data['material'] ?>" hidden>
                            <input name="jumlahlama" type="text" value="<?= $data['jumlah'] ?>" hidden>
                            <td><input class="form-control form-control-sm" name="tipe" type="text" value="<?= $data['tipe'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="material" type="text" value="<?= $data['material'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="jumlah" type="text" value="<?= $data['jumlah'] ?>"></td>
                            <td><button class="btn btn-sm btn-warning" name="updatefoc" type="submit">Ubah</button></td>
                            <td><button class="btn btn-sm btn-danger" name="deletefoc" type="submit">Delete</button></td>
                        </tr>
                    </form>
                <?php
                }
                ?>
            </table>
        </div>
        <br><br>

        <?php
        if (isset($_POST['updatefoc'])) {
            $tipelama = $_POST['tipelama'];
            $materialama = $_POST['materialama'];
            $jumlahlama = $_POST['jumlahlama'];
            $updatejumlah = $_POST['jumlah'];
            $updateid = $_POST['id'];
            $updatetipe = $_POST['tipe'];
            $updatematerial = $_POST['material'];
            $update = mysqli_query($connect, "UPDATE material_validator SET tipe='$updatetipe', material='$updatematerial', jumlah='$updatejumlah' WHERE id='$updateid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Update Material $materialama Menjadi $updatematerial, Tipe $tipelama Menjadi $updatetipe Dan Jumlah $jumlahlama Menjadi $updatejumlah')");
            echo "Data Berhasil Diupdate";
        }
        if (isset($_POST['deletefoc'])) {
            $materialama = $_POST['materialama'];
            $deleteid = $_POST['id'];
            $delete = mysqli_query($connect, "DELETE FROM material_validator WHERE id='$deleteid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Material $materialama Dihapus')");
            echo "Data Berhasil Dihapus";
        }
        ?>


        <div style="overflow:scroll; width:100%; height:500px;">
            <table border="1" class="table table-condensed">
                <tr>
                    <th colspan="5" class="text-center">FTTH</th>
                </tr>
                <tr>
                    <th>Tipe</th>
                    <th>Material</th>
                    <th>Jumlah</th>
                    <th colspan="2">Aksi</th>
                </tr>
                <?php
                $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='ftth'");
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <form action="materialmanager.php" method="POST">
                        <tr>
                            <input name="id" type="text" value="<?= $data['id'] ?>" hidden>
                            <input name="tipelama" type="text" value="<?= $data['tipe'] ?>" hidden>
                            <input name="materialama" type="text" value="<?= $data['material'] ?>" hidden>
                            <input name="jumlahlama" type="text" value="<?= $data['jumlah'] ?>" hidden>
                            <td><input class="form-control form-control-sm" name="tipe" type="text" value="<?= $data['tipe'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="material" type="text" value="<?= $data['material'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="jumlah" type="text" value="<?= $data['jumlah'] ?>"></td>
                            <td><button class="btn btn-sm btn-warning" name="updateftth" type="submit">Ubah</button></td>
                            <td><button class="btn btn-sm btn-danger" name="deleteftth" type="submit">Delete</button></td>
                        </tr>
                    </form>
                <?php
                }
                ?>
            </table>
        </div>
        <br><br>

        <?php
        if (isset($_POST['updateftth'])) {
            $tipelama = $_POST['tipelama'];
            $materialama = $_POST['materialama'];
            $jumlahlama = $_POST['jumlahlama'];
            $updatejumlah = $_POST['jumlah'];
            $updateid = $_POST['id'];
            $updatetipe = $_POST['tipe'];
            $updatematerial = $_POST['material'];
            $update = mysqli_query($connect, "UPDATE material_validator SET tipe='$updatetipe', material='$updatematerial', jumlah='$updatejumlah' WHERE id='$updateid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Update Material $materialama Menjadi $updatematerial, Tipe $tipelama Menjadi $updatetipe Dan Jumlah $jumlahlama Menjadi $updatejumlah')");
            echo "Data Berhasil Diupdate";
        }
        if (isset($_POST['deleteftth'])) {
            $materialama = $_POST['materialama'];
            $deleteid = $_POST['id'];
            $delete = mysqli_query($connect, "DELETE FROM material_validator WHERE id='$deleteid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Material $materialama Dihapus')");
            echo "Data Berhasil Dihapus";
        }
        ?>


        <div style="overflow:scroll; width:100%; height:500px;">
            <table border="1" class="table table-condensed">
                <tr>
                    <th colspan="5" class="text-center">FOT</th>
                </tr>
                <tr>
                    <th>Tipe</th>
                    <th>Material</th>
                    <th>Jumlah</th>
                    <th colspan="2">Aksi</th>
                </tr>
                <?php
                $query = mysqli_query($connect, "SELECT * FROM material_validator WHERE tipe='fot'");
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <form action="materialmanager.php" method="POST">
                        <tr>
                            <input name="id" type="text" value="<?= $data['id'] ?>" hidden>
                            <input name="tipelama" type="text" value="<?= $data['tipe'] ?>" hidden>
                            <input name="materialama" type="text" value="<?= $data['material'] ?>" hidden>
                            <input name="jumlahlama" type="text" value="<?= $data['jumlah'] ?>" hidden>
                            <td><input class="form-control form-control-sm" name="tipe" type="text" value="<?= $data['tipe'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="material" type="text" value="<?= $data['material'] ?>"></td>
                            <td><input class="form-control form-control-sm" name="jumlah" type="text" value="<?= $data['jumlah'] ?>"></td>
                            <td><button class="btn btn-sm btn-warning" name="updatefot" type="submit">Ubah</button></td>
                            <td><button class="btn btn-sm btn-danger" name="deletefot" type="submit">Delete</button></td>
                        </tr>
                    </form>
                <?php
                }
                ?>
            </table>
        </div>
        <br><br>

        <?php
        if (isset($_POST['updatefot'])) {
            $tipelama = $_POST['tipelama'];
            $materialama = $_POST['materialama'];
            $jumlahlama = $_POST['jumlahlama'];
            $updatejumlah = $_POST['jumlah'];
            $updateid = $_POST['id'];
            $updatetipe = $_POST['tipe'];
            $updatematerial = $_POST['material'];
            $update = mysqli_query($connect, "UPDATE material_validator SET tipe='$updatetipe', material='$updatematerial', jumlah='$updatejumlah' WHERE id='$updateid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Update Material $materialama Menjadi $updatematerial, Tipe $tipelama Menjadi $updatetipe Dan Jumlah $jumlahlama Menjadi $updatejumlah')");
            echo "Data Berhasil Diupdate";
        }
        if (isset($_POST['deletefot'])) {
            $materialama = $_POST['materialama'];
            $deleteid = $_POST['id'];
            $delete = mysqli_query($connect, "DELETE FROM material_validator WHERE id='$deleteid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Material Manager Tab - Material $materialama Dihapus')");
            echo "Data Berhasil Dihapus";
        }
        ?>
    </div>
</body>

</html>
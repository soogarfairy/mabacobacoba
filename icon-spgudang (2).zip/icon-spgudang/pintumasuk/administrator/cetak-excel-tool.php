<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
if (isset($_GET['pesan'])) {
    if ($_GET['pesan'] == 'cetak-excel') {
        // filename for download
        $filename = "data_tool_" . date('Ymd') . ".xls";
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Type: application/vnd.ms-excel");
    }
}
?>
<!DOCTYPE html>
<html>

<head></head>

<body>
    <div id="container">
        <table id="dataTool" class="table table-condensed" border="1">
            <tr>
                <th class="text-center">No</th>
                <th class="text-center">Tipe</th>
                <th class="text-center">Tool</th>
            </tr>
            <?php
            $no = 1;
            $query = mysqli_query($connect, "SELECT * FROM tool_validator ORDER BY tipe");
            while ($data = mysqli_fetch_array($query)) {
            ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $data['tipe'] ?></td>
                    <td><?= $data['tool'] ?></td>
                </tr>
            <?php
                $no++;
            }
            ?>
        </table>
    </div>
</body>

</html>
<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>List Kotak Suara</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a class="active" href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <?php
    if (isset($_POST['delete'])) {
        $nama = $_POST['nama'];
        $id = $_POST['id'];
        $query = mysqli_query($connect, "DELETE FROM feedback WHERE id='$id'");
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kotak Suara Tab - Saran & Masukan Dari $nama Dihapus')");
        echo "Pesan Berhasil Dihapus!";
    }
    ?>
    <h2 align="center">List Kritik & Saran</h2>
    <br>
    <div class=" container">
        <?php
        $no = 1;
        $query = mysqli_query($connect, "SELECT * FROM feedback ORDER BY id DESC");
        $row = mysqli_num_rows($query);
        if ($row > 0) {
        ?>
            <table class="table-primary table-bordered table-striped table-hover table-dark table">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Tim</th>
                    <th>Email</th>
                    <th>Pesan</th>
                    <th>Aksi</th>
                </tr>
                <?php
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><?= $data['nama'] ?></td>
                        <td><?= $data['divisi'] ?></td>
                        <td><?= $data['email'] ?></td>
                        <td><?= $data['feedback'] ?></td>
                        <form action="feedback.php" method="POST">
                            <input type="text" name="id" value="<?= $data['id'] ?>" hidden>
                            <input type="text" name="nama" value="<?= $data['nama'] ?>" hidden>
                            <td><button class="btn btn-danger" name="delete" type="submit">DELETE</button></td>
                        </form>
                    </tr>
                <?php
                    $no++;
                }
                ?>
            </table>
        <?php
        }
        ?>
    </div>
</body>

</html>
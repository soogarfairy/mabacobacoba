<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";

if (isset($_POST['tambah-data-pengadaan-perangkat'])) {
    $perangkat = mysqli_real_escape_string($connect, $_POST['perangkat']);
    $nospr = mysqli_real_escape_string($connect, $_POST['nospr']);
    $nosn = mysqli_real_escape_string($connect, $_POST['nosn']);
    $jml = mysqli_real_escape_string($connect, $_POST['jumlah']);
    $cek = mysqli_query($connect, "SELECT * FROM pengadaan_validator WHERE no_sn='$nosn'");
    if (mysqli_num_rows($cek) > 0) {
        header("location:pengelolaan-pengadaan.php?pesan=inputgagal");
    } else {
        $query = mysqli_query($connect, "INSERT INTO pengadaan_validator VALUES('','$perangkat','$nospr','$nosn','$jml')");
        if ($query) {
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Pengadaan Tab - Tambah Data $perangkat')");
            header("location:pengelolaan-pengadaan.php?pesan=inputsukses");
        } else {
            header("location:pengelolaan-pengadaan.php?pesan=inputgagal");
        }
    }
}
if (isset($_POST['update-pengadaan-perangkat'])) {
    $id = mysqli_real_escape_string($connect, $_POST['id']);
    $perangkat = mysqli_real_escape_string($connect, $_POST['perangkat']);
    $nospr = mysqli_real_escape_string($connect, $_POST['nospr']);
    $nosn = mysqli_real_escape_string($connect, $_POST['nosn']);
    $jml = mysqli_real_escape_string($connect, $_POST['jumlah']);
    $query = mysqli_query($connect, "UPDATE pengadaan_validator SET nama_perangkat='$perangkat', no_spr='$nospr',no_sn='$nosn', jumlah='$jml' WHERE id='$id'");
    if ($query) {
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Pengadaan Tab - Update Data $perangkat')");
        header("location:pengelolaan-pengadaan.php?pesan=updatesukses");
    } else {
        header("location:pengelolaan-pengadaan.php?pesan=updategagal");
    }
}
if (isset($_POST['delete-pengadaan-perangkat'])) {
    $id = mysqli_real_escape_string($connect, $_POST['id']);
    $query = mysqli_query($connect, "DELETE FROM pengadaan_validator WHERE id='$id'");
    if ($query) {
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Pengadaan Tab - Hapus Data $perangkat')");
        header("location:pengelolaan-pengadaan.php?pesan=deletesukses");
    } else {
        header("location:pengelolaan-pengadaan.php?pesan=deletegagal");
    }
}
if (isset($_POST['adddivisi'])) {
    $divisi = mysqli_real_escape_string($connect, $_POST['divisi']);
    $query = mysqli_query($connect, "INSERT INTO menu_divisi VALUES(null,'$divisi')");
    if ($query) {
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Menu Tim - Tambah Tim $divisi')");
        header("location:dashboard.php?pesan=tambahtimsukses");
    } else {
        header("location:dashboard.php?pesan=tambahtimgagal");
    }
}
if (isset($_POST['updatemenudivisi'])) {
    $id = mysqli_real_escape_string($connect, $_POST['id']);
    $divisi = mysqli_real_escape_string($connect, $_POST['divisi']);
    $query = mysqli_query($connect, "UPDATE menu_divisi SET divisi='$divisi' WHERE id='$id'");
    if ($query) {
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Menu Tim - Update Tim $divisi')");
        header("location:dashboard.php?pesan=updatetimsukses");
    } else {
        header("location:dashboard.php?pesan=updatetimgagal");
    }
}
if (isset($_POST['deletemenudivisi'])) {
    $id = mysqli_real_escape_string($connect, $_POST['id']);
    $divisi = mysqli_real_escape_string($connect, $_POST['divisi']);
    $query = mysqli_query($connect, "DELETE FROM menu_divisi WHERE id='$id'");
    if ($query) {
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Menu Tim - Delete Tim $divisi')");
        header("location:dashboard.php?pesan=deletetimsukses");
    } else {
        header("location:dashboard.php?pesan=deletetimgagal");
    }
}

if (isset($_POST['addpenerima'])) {
    $penerima = mysqli_real_escape_string($connect, $_POST['penerima']);
    $query = mysqli_query($connect, "INSERT INTO menu_penerima VALUES(null,'$penerima')");
    if ($query) {
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Menu Penerima - Tambah Penerima $penerima')");
        header("location:dashboard.php?pesan=tambahpenerimasukses");
    } else {
        header("location:dashboard.php?pesan=tambahpenerimagagal");
    }
}
if (isset($_POST['updatemenupenerima'])) {
    $id = mysqli_real_escape_string($connect, $_POST['id']);
    $penerima = mysqli_real_escape_string($connect, $_POST['penerima']);
    $query = mysqli_query($connect, "UPDATE menu_penerima SET penerima='$penerima' WHERE id='$id'");
    if ($query) {
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Menu Penerima - Update Penerima $penerima')");
        header("location:dashboard.php?pesan=updatepenerimasukses");
    } else {
        header("location:dashboard.php?pesan=updatepenerimagagal");
    }
}
if (isset($_POST['deletemenupenerima'])) {
    $id = mysqli_real_escape_string($connect, $_POST['id']);
    $penerima = mysqli_real_escape_string($connect, $_POST['penerima']);
    $query = mysqli_query($connect, "DELETE FROM menu_penerima WHERE id='$id'");
    if ($query) {
        $tgl = date("Y-m-d H:i:s");
        $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Kelola Menu Penerima - Delete Penerima $penerima')");
        header("location:dashboard.php?pesan=deletepenerimasukses");
    } else {
        header("location:dashboard.php?pesan=deletepenerimagagal");
    }
}

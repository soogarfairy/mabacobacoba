<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
if (isset($_GET['pesan'])) {
    if ($_GET['pesan'] == 'cetak-excel') {
        // filename for download
        $filename = "pengadaan_perangkat_" . date('Ymd') . ".xls";
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header("Content-Type: application/vnd.ms-excel");
    }
}
?>
<!DOCTYPE html>
<html>

<head></head>

<body>
    <div id="container">
        <table id="dataPengadaan" class="table table-condensed" border="1">
            <tr>
                <th class="text-center">No</th>
                <th class="text-center">Nama Material</th>
                <th class="text-center">Nomor SPR</th>
                <th class="text-center">Serial Number</th>
                <th class="text-center">Jumlah</th>
            </tr>
            <?php
            $no = 1;
            $query = mysqli_query($connect, "SELECT * FROM pengadaan_validator");
            if (mysqli_num_rows($query) > 0) {
                while ($data = mysqli_fetch_array($query)) {
            ?>
                    <tr>
                        <td><?= $no ?></td>
                        <td><?= $data['nama_perangkat'] ?></td>
                        <td><?= $data['no_spr'] ?></td>
                        <td><?= $data['no_sn'] ?></td>
                        <td><?= $data['jumlah'] ?></td>
                    </tr>
                <?php
                    $no++;
                }
            } else {
                ?>
                <tr>
                    <td colspan="7">Belum Ada Data</td>
                </tr>
            <?php
            }

            ?>
        </table>
    </div>
</body>

</html>
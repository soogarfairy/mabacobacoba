<?php
// mengaktifkan session
session_start();
include "../../koneksi/conn.php";

$tgl = date("Y-m-d H:i:s");
$log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Logged Out')");

// menghapus semua session
session_destroy();

// mengalihkan halaman sambil mengirim pesan logout
header("location:../index.php?pesan=logout");

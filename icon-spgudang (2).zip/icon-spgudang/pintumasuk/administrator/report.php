<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>Active</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a class="active" href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <div class="container">
        <br>
        <?php
        if (isset($_POST['delete'])) {
            $kode = $_POST['kode'];
            $tool = $_POST['tool'];
            $update = mysqli_query($connect, "UPDATE tool_validator SET jumlah='1' WHERE tool='$tool'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Active Tab - Hapus Data Tool $tool Dari Peminjaman $kode')");
            echo "Data Berhasil Dihapus!";
        }
        if (isset($_POST['statuscomplete'])) {
            $kode = $_POST['kode'];
            $changestatus = mysqli_query($connect, "UPDATE transaksi_peminjam SET status='COMPLETED' WHERE kode='$kode'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Active Tab - Perubahan Status Active Ke Completed Dari Peminjaman $kode')");
            echo "Status Berhasil Diubah, Silakan Cek Pada Dashboard Completed!";
        }

        if (isset($_POST['singlesort'])) {
            $kode = $_POST['singlesort'];
            $query = mysqli_query($connect, "SELECT * FROM transaksi_peminjam WHERE kode='$kode'");
            while ($data = mysqli_fetch_array($query)) {
                $tool = mysqli_query($connect, "SELECT * FROM transaksi_tool WHERE kode='$data[kode]'");
                $material = mysqli_query($connect, "SELECT * FROM transaksi_material WHERE kode='$data[kode]'");
                $soio = mysqli_query($connect, "SELECT * FROM transaksi_soiouser WHERE kode='$data[kode]'");
                $pengadaan = mysqli_query($connect, "SELECT * FROM transaksi_pengadaan WHERE kode='$data[kode]'");
        ?>
                <div style="overflow:scroll; width:850px; height:250px;">
                    <table border="1">
                        <tr>
                            <th>Nama</th>
                            <th>Tim</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Kode Pinjam</th>
                            <th>Aksi</th>
                        </tr>
                        <tr>
                            <td><?= $data['nama'] ?></td>
                            <td><?= $data['divisi'] ?></td>
                            <td><?= $data['tanggal'] ?></td>
                            <td><?= $data['status'] ?></td>
                            <td><?= $data['kode'] ?></td>
                            <form action="report.php" method="POST">
                                <input name="kode" type="text" value="<?= $data['kode'] ?>" hidden>
                                <td><button type="submit" name="statuscomplete">Completed</button></td>
                            </form>
                        </tr>

                        <tr>
                            <th>SO/IO</th>
                            <th>User</th>
                        </tr>
                        <?php

                        while ($data1 = mysqli_fetch_array($soio)) {
                        ?>
                            <tr>
                                <td><?= $data1['soio'] ?></td>
                                <td><?= $data1['user'] ?></td>
                            </tr>
                        <?php
                        }
                        ?>

                        <tr>
                            <th>Tool</th>
                        </tr>
                        <tr>
                            <?php
                            while ($data2 = mysqli_fetch_array($tool)) {
                                $validator = mysqli_query($connect, "SELECT * FROM tool_validator WHERE tool='$data2[tool]' AND jumlah='0'");
                                while ($data3 = mysqli_fetch_array($validator)) {
                            ?>
                                    <form method="POST" action="report.php">
                                        <input type="text" name="kode" value="<?= $data['kode'] ?>" hidden>
                                        <input type="text" name="tool" value="<?= $data3['tool'] ?>" hidden>
                                        <td><?= $data3['tool'] ?> <button type="submit" name="delete">Delete</button></td>
                                    </form>
                            <?php
                                }
                            }
                            ?>
                        </tr>
                        <tr>
                            <th>Tipe</th>
                            <th>Material</th>
                            <th>Jumlah Terpakai</th>
                        </tr>
                        <?php
                        while ($data4 = mysqli_fetch_array($material)) {
                        ?>
                            <tr>
                                <td><?= $data4['tipe'] ?></td>
                                <td><?= $data4['material'] ?></td>
                                <td><?= $data4['jumlah'] ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                        <tr>
                            <th>Perangkat</th>
                            <th>No SPR</th>
                            <th>No SN</th>
                            <th>Jumlah</th>
                        </tr>
                        <?php
                        while ($data5 = mysqli_fetch_array($pengadaan)) {
                        ?>
                            <tr>
                                <td><?= $data5['perangkat'] ?></td>
                                <td><?= $data5['nospr'] ?></td>
                                <td><?= $data5['nosn'] ?></td>
                                <td><?= $data5['jumlah'] ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                        <tr>
                            <th>Note</th>
                        </tr>
                        <tr>
                            <td><?= $data['note'] ?></td>
                        </tr>
                    </table>
                </div>
                <?php

            }
        } else {
            $query = mysqli_query($connect, "SELECT * FROM transaksi_peminjam WHERE status='ACTIVE' ORDER BY tanggal DESC");
            $cek = mysqli_num_rows($query);
            if ($cek > 0) {
                while ($data = mysqli_fetch_array($query)) {
                    $soio = mysqli_query($connect, "SELECT * FROM transaksi_soiouser WHERE kode='$data[kode]'");
                    $tool = mysqli_query($connect, "SELECT * FROM transaksi_tool WHERE kode='$data[kode]'");
                    $material = mysqli_query($connect, "SELECT * FROM transaksi_material WHERE kode='$data[kode]'");
                    $pengadaan = mysqli_query($connect, "SELECT * FROM transaksi_pengadaan WHERE kode='$data[kode]'");
                ?>
                    <div style="overflow:scroll; width:850px; height:250px;">
                        <table border="1">
                            <tr>
                                <th>Nama</th>
                                <th>Tim</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Kode Pinjam</th>
                                <th>Aksi</th>
                            </tr>
                            <tr>
                                <td><?= $data['nama'] ?></td>
                                <td><?= $data['divisi'] ?></td>
                                <td><?= $data['tanggal'] ?></td>
                                <td><?= $data['status'] ?></td>
                                <td><?= $data['kode'] ?></td>
                                <form action="report.php" method="POST">
                                    <input name="kode" type="text" value="<?= $data['kode'] ?>" hidden>
                                    <td><button type="submit" name="statuscomplete">Completed</button></td>
                                </form>
                            </tr>

                            <tr>
                                <th>SO/IO</th>
                                <th>User</th>
                            </tr>
                            <?php
                            while ($data1 = mysqli_fetch_array($soio)) {
                            ?>
                                <tr>
                                    <td><?= $data1['soio'] ?></td>
                                    <td><?= $data1['user'] ?></td>
                                </tr>
                            <?php
                            }
                            ?>

                            <tr>
                                <th>Tool</th>
                            </tr>
                            <tr>
                                <?php
                                while ($data2 = mysqli_fetch_array($tool)) {
                                    $validator = mysqli_query($connect, "SELECT * FROM tool_validator WHERE tool='$data2[tool]' AND jumlah='0'");
                                    while ($data3 = mysqli_fetch_array($validator)) {
                                ?>
                                        <form method="POST" action="report.php">
                                            <input type="text" name="kode" value="<?= $data['kode'] ?>" hidden>
                                            <input type="text" name="tool" value="<?= $data3['tool'] ?>" hidden>
                                            <td><?= $data3['tool'] ?> <button type="submit" name="delete">Delete</button></td>
                                        </form>
                                <?php
                                    }
                                }
                                ?>
                            </tr>

                            <tr>
                                <th>Tipe</th>
                                <th>Material</th>
                                <th>Jumlah Terpakai</th>
                            </tr>
                            <?php
                            while ($data4 = mysqli_fetch_array($material)) {
                            ?>
                                <tr>
                                    <td><?= $data4['tipe'] ?></td>
                                    <td><?= $data4['material'] ?></td>
                                    <td><?= $data4['jumlah'] ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                            <tr>
                                <th>Perangkat</th>
                                <th>No SPR</th>
                                <th>No SN</th>
                                <th>Jumlah</th>
                            </tr>
                            <?php
                            while ($data5 = mysqli_fetch_array($pengadaan)) {
                            ?>
                                <tr>
                                    <td><?= $data5['perangkat'] ?></td>
                                    <td><?= $data5['nospr'] ?></td>
                                    <td><?= $data5['nosn'] ?></td>
                                    <td><?= $data5['jumlah'] ?></td>
                                </tr>
                            <?php
                            }
                            ?>
                            <tr>
                                <th>Note</th>
                            </tr>
                            <tr>
                                <td><?= $data['note'] ?></td>
                            </tr>
                        </table>
                    </div>
        <?php
                }
            } else {
                echo "<h3>DATA TIDAK DITEMUKAN</h3>";
            }
        }
        ?>
    </div>
</body>

</html>
<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>Dashboard</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="../js/FileSaverExcel.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a class="active" href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <div class="container">
        <br>
        <form method="POST" action="catatan.php">
            <table id="dinamisx">
                <tr>
                    <th>Q-CODE</th>
                    <th>Nama Pengembali</th>
                    <th>Tim</th>
                    <th>Tanggal</th>
                    <th>Penerima</th>
                    <th>Material</th>
                    <th>Jumlah</th>
                </tr>
                <tr>
                    <td><input type="text" name="kode"></td>
                    <td><input type="text" name="pengembali"></td>
                    <td>
                        <select name="divisi">
                            <option selected disabled>PILIH</option>
                            <?php
                            $qmenudiv = mysqli_query($connect, "SELECT * FROM menu_divisi");
                            while ($data = mysqli_fetch_array($qmenudiv)) {
                            ?>
                                <option value="<?= $data['divisi'] ?>"><?= ucwords($data['divisi']) ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </td>
                    <td>
                        <input type="date" name="tanggal">
                    </td>
                    <td>
                        <select name="penerima">
                            <option selected>Pilih Penerima</option>
                            <?php
                            $qmenupenerima = mysqli_query($connect, "SELECT * FROM menu_penerima");
                            while ($data = mysqli_fetch_array($qmenupenerima)) {
                            ?>
                                <option value="<?= $data['penerima'] ?>"><?= ucwords($data['penerima']) ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </td>
                    <td>
                        <select name="material">
                            <option selected disabled>PILIH MATERIAL</option>
                            <?php
                            $materiallist = mysqli_query($connect, "SELECT * FROM material_validator ORDER BY tipe");
                            while ($data = mysqli_fetch_array($materiallist)) {
                            ?>
                                <option name="material" value="<?= $data['tipe'] . "_" . $data['material'] ?>"><?= $data['tipe'] . "_" . $data['material'] ?></option>
                            <?php
                            }
                            ?>
                        </select>
                    </td>
                    <td>
                        <input type="number" name="jumlah">
                    </td>
                </tr>
                <tr>
                    <td><button type="submit" name="submit">SUBMIT</button></td>
                </tr>
            </table>
        </form>
        <?php
        if (isset($_POST['submit'])) {
            $kode = $_POST['kode'];
            $pengembali = $_POST['pengembali'];
            $divisi = $_POST['divisi'];
            $tanggal = $_POST['tanggal'];
            $penerima = $_POST['penerima'];
            $material = $_POST['material'];
            $jumlah = $_POST['jumlah'];
            $query = mysqli_query($connect, "INSERT INTO catatan_amal_pengembali (id,kode,nama_pengembali,divisi,tanggal,penerima,material,jumlah) VALUES ('','$kode','$pengembali','$divisi','$tanggal','$penerima','$material','$jumlah')");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Catatan Tab - Data Kode $kode Ditambahkan')");
        }
        ?>
        <form method="POST" action="catatan.php">
            <br>Tanggal : <input type="date" name="tanggalmulai"> - <input type="date" name="tanggalselesai">
            <br><br>
            <select name="sortdivisi">
                <option selected disabled>PILIH</option>
                <?php
                $qmenudiv = mysqli_query($connect, "SELECT * FROM menu_divisi");
                while ($data = mysqli_fetch_array($qmenudiv)) {
                ?>
                    <option value="<?= $data['divisi'] ?>"><?= ucwords($data['divisi']) ?></option>
                <?php
                }
                ?>
            </select>
            <br><br>
            <button name="sort">SORT</button>
        </form>
        <br>
        <button class="btn-primary btn-sm" onclick="exportTableToExcel('dataCAB','catatan-amal')">Export Catatan to Excel</button>
        <br>
        <table border="1" id="dataCAB">
            <tr>
                <th>No</th>
                <th>Q-CODE</th>
                <th>Nama Pengembali</th>
                <th>Tim</th>
                <th>Tanggal</th>
                <th>Penerima</th>
                <th>Material</th>
                <th>Jumlah</th>
                <th>Aksi</th>
            </tr>
            <?php
            if (isset($_POST['sort'])) {
                $startdate = $_POST['tanggalmulai'];
                $enddate = $_POST['tanggalselesai'];
                $sortdivisi = $_POST['sortdivisi'];
                if (!empty($startdate) && !empty($sortdivisi)) {
                    $cetak = mysqli_query($connect, "SELECT * FROM catatan_amal_pengembali WHERE divisi='$sortdivisi' AND tanggal BETWEEN '$startdate' AND '$enddate' ORDER BY tanggal ASC");
                    $no = 1;
                    while ($data = mysqli_fetch_array($cetak)) {
            ?>
                        <form action="catatan.php" method="POST">
                            <tr>
                                <td><?= $no ?></td>
                                <td><?= $data['kode'] ?></td>
                                <td><?= $data['nama_pengembali'] ?></td>
                                <td><?= $data['divisi'] ?></td>
                                <td><?= $data['tanggal'] ?></td>
                                <td><?= $data['penerima'] ?></td>
                                <td><?= $data['material'] ?></td>
                                <td><?= $data['jumlah'] ?></td>
                                <td><input name="id" type="text" value="<?= $data['id'] ?>" hidden> <button name="deleterow" type="submit">DELETE</button> </td>
                            </tr>
                        </form>
                    <?php
                        $no++;
                    }
                } elseif (!empty($startdate) && empty($sortdivisi)) {
                    $cetak = mysqli_query($connect, "SELECT * FROM catatan_amal_pengembali WHERE tanggal BETWEEN '$startdate' AND '$enddate' ORDER BY tanggal ASC");
                    $no = 1;
                    while ($data = mysqli_fetch_array($cetak)) {
                    ?>
                        <form action="catatan.php" method="POST">
                            <tr>
                                <td><?= $no ?></td>
                                <td><?= $data['kode'] ?></td>
                                <td><?= $data['nama_pengembali'] ?></td>
                                <td><?= $data['divisi'] ?></td>
                                <td><?= $data['tanggal'] ?></td>
                                <td><?= $data['penerima'] ?></td>
                                <td><?= $data['material'] ?></td>
                                <td><?= $data['jumlah'] ?></td>
                                <td><input name="id" type="text" value="<?= $data['id'] ?>" hidden> <button name="deleterow" type="submit">DELETE</button> </td>
                            </tr>
                        </form>
                    <?php
                        $no++;
                    }
                }
            } else {
                $cetak = mysqli_query($connect, "SELECT * FROM catatan_amal_pengembali ORDER BY tanggal ASC");
                $no = 1;
                while ($data = mysqli_fetch_array($cetak)) {
                    ?>
                    <form action="catatan.php" method="POST">
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $data['kode'] ?></td>
                            <td><?= $data['nama_pengembali'] ?></td>
                            <td><?= $data['divisi'] ?></td>
                            <td><?= $data['tanggal'] ?></td>
                            <td><?= $data['penerima'] ?></td>
                            <td><?= $data['material'] ?></td>
                            <td><?= $data['jumlah'] ?></td>
                            <td>
                                <input name="id" type="text" value="<?= $data['id'] ?>" hidden>
                                <input name="kode" type="text" value="<?= $data['kode'] ?>" hidden>
                                <button name="deleterow" type="submit">DELETE</button>
                            </td>
                        </tr>
                    </form>
            <?php
                    $no++;
                }
            }
            if (isset($_POST['deleterow'])) {
                $kode = $_POST['kode'];
                $id = $_POST['id'];
                $delete = mysqli_query($connect, "DELETE FROM catatan_amal_pengembali WHERE id='$id'");
                $tgl = date("Y-m-d H:i:s");
                $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Catatan Tab - Data Kode $kode Dihapus')");
                echo "DATA BERHASIL DIDELETE";
            }
            ?>
        </table>
    </div>
</body>

</html>
<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>Account Manager</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a class="active" href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <?php
    if ($_SESSION['priv'] != "admin") {
        echo "<h4 align='center' style='color:red;'>MAAF, ANDA BUKAN ADMIN</h4>";
    } else {
        if (isset($_POST['add'])) {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $priv = $_POST['priv'];
            $query = mysqli_query($connect, "INSERT INTO akun VALUES ('','$username','$password','$priv')");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Account Manager Tab - Akun $username Sebagai $priv Ditambahkan')");
            echo "Akun Berhasil Ditambah!";
        }
        if (isset($_POST['update'])) {
            $id = $_POST['id'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            $priv = $_POST['priv'];
            $query = mysqli_query($connect, "UPDATE akun SET username='$username', password='$password', priv='$priv' WHERE id='$id'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Account Manager Tab - Akun $username Berhasil Diupdate')");
            echo "Akun Berhasil Diupdate!";
        }
        if (isset($_POST['delete'])) {
            $id = $_POST['id'];
            $username = $_POST['username'];
            $query = mysqli_query($connect, "DELETE FROM akun WHERE id='$id'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Account Manager Tab - Akun $username Dihapus')");
            echo "Akun Berhasil Dihapus!";
        }
    ?>
        <div class="container">
            <br>
            <h4 align="center">ACCOUNT MANAGER</h4>
            <br>
            <form action="account-manager.php" method="POST">
                <table>
                    <tr>
                        <th class="text-center" colspan="3">FORM TAMBAH AKUN</th>
                    </tr>
                    <tr>
                        <td>Username</td>
                        <td>:</td>
                        <td><input type="text" name="username" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td>:</td>
                        <td><input type="text" name="password" class="form-control"></td>
                    </tr>
                    <tr>
                        <td>Privilege</td>
                        <td>:</td>
                        <td>
                            <select name="priv" class="form-control">
                                <option selected disabled>PILIH</option>
                                <option value="moderator">Moderator</option>
                                <option value="admin">Admin</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <button class="btn btn-success" name="add" type="submit">TAMBAH</button>
                        </td>
                    </tr>
                </table>
            </form>
            <br>
            <br>
            <table class="table-primary table-bordered table-striped table-hover table-dark table">
                <tr>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Privilege</th>
                    <th>Aksi</th>
                </tr>
                <?php
                $query = mysqli_query($connect, "SELECT * FROM akun ORDER BY priv");
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <form action="account-manager.php" method="POST">
                        <tr>
                            <input type="text" name="id" value="<?= $data['id'] ?>" hidden>
                            <td><input type="text" name="username" value="<?= $data['username'] ?>" class="form-control"></td>
                            <td><input type="text" name="password" value="<?= $data['password'] ?>" class="form-control"></td>
                            <td><input type="text" name="priv" value="<?= $data['priv'] ?>" class="form-control"></td>
                            <td>
                                <button class="btn btn-info" name="update" type="submit">UPDATE</button>
                                <button class="btn btn-danger" name="delete" type="submit">DELETE</button>
                            </td>
                        </tr>
                    </form>
                <?php
                }
                ?>
            </table>
        </div>
    <?php
    }
    ?>
</body>

</html>
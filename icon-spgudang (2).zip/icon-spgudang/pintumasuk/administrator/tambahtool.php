<?php
session_start();
if ($_SESSION['status'] != "login") {
    header("location:../index.php?pesan=belum_login");
}
include "../../koneksi/conn.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>Tambah Tool</title>
    <link href="https://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css" />
    <link href="gayain.css" rel="stylesheet" type="text/css">
    <script src="https:/netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
    <script src="https:/code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="../js/FileSaverExcel.js"></script>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #f1f1f1;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a.active {
            background-color: #4CAF50;
            color: white;
        }

        li a:hover:not(.active) {
            background-color: #555;
            color: white;
        }

        .welc {
            display: block;
            color: #000;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <ul>
        <li class="welc">Welcome <?= ucfirst($_SESSION['priv']) ?> <?= ucfirst($_SESSION['username']) ?></li>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="report.php">Active</a></li>
        <li><a href="completed.php">Completed</a></li>
        <li><a class="active" href="tambahtool.php">Tool</a></li>
        <li><a href="materialmanager.php">Material</a></li>
        <li><a href="pengelolaan-pengadaan.php">Pengadaan</a></li>
        <li><a href="catatan.php">Catatan Pengembalian</a></li>
        <li><a href="feedback.php">List Kotak Suara</a></li>
        <li><a href="account-manager.php">Akun Manager</a></li>
        <li><a href="log.php">Log</a></li>
        <li><a href="logout.php">Log Out</a></li>
    </ul>
    <div class="container">
        <h4>FORM TAMBAH TOOL</h4>
        <form action="tambahtool.php" method="POST">
            <p>Nama Tool : <input name="tool" type="text" required></p>
            <p>Tipe : <select name="tipe" required>
                    <option selected disabled>PILIH</option>
                    <option value="aklik">AKLIK</option>
                    <option value="aklis">AKLIS</option>
                    <option value="bertest">BERTEST</option>
                    <option value="console">CONSOLE</option>
                    <option value="crimping">CRIMPING</option>
                    <option value="focaklik">FOCAKLIK</option>
                    <option value="gps">GPS</option>
                    <option value="helm">HELM</option>
                    <option value="laser">LASER</option>
                    <option value="opm">OPM</option>
                    <option value="payung">PAYUNG</option>
                    <option value="printlabel">PRINTLABEL</option>
                    <option value="switchtest">SWITCHTEST</option>
                    <option value="tangga">TANGGA</option>
                    <option value="teropong">TEROPONG</option>
                    <option value="toolkit">TOOLKIT</option>
                    <option value="walkingmeter">WALKINGMETER</option>
                    <option value="wearpack_rompi">WEARPACK_ROMPI_KACAMATA</option>
                </select></p>
            <button class="btn btn-sm btn-primary" type="submit" name="add">Tambah Tool</button>
        </form>
        <br>
        <?php
        if (isset($_POST['add'])) {
            $tipe = $_POST['tipe'];
            $tool = $_POST['tool'];
            $tambah = mysqli_query($connect, "INSERT INTO tool_validator (id,tool,jumlah,tipe) VALUES ('','$tool','1','$tipe')");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Tool Manager Tab - Tool $tool Ditambahkan')");
            header("location:tambahtool.php");
            echo "Data Berhasil Ditambahkan";
        ?>
        <?php
        }
        ?>
        <h4>DATA TOOLS</h4>
        <div style="overflow:scroll; width:100%; height:500px;">
            <table id="dataTool" class="table table-condensed">
                <tr>
                    <th class="text-center">No</th>
                    <th class="text-center">Tipe</th>
                    <th class="text-center">Tool</th>
                    <th class="text-center">Aksi</th>
                </tr>
                <?php
                $no = 1;
                $query = mysqli_query($connect, "SELECT * FROM tool_validator ORDER BY tipe");
                while ($data = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <form action="tambahtool.php" method="POST">
                            <input name="id" type="text" value="<?= $data['id'] ?>" hidden>
                            <input name="toolama" type="text" value="<?= $data['tool'] ?>" hidden>
                            <input name="tipelama" type="text" value="<?= $data['tipe'] ?>" hidden>
                            <td><?= $no ?></td>
                            <td><input name="tipe" type="text" value="<?= $data['tipe'] ?>" class="form-control form-control-sm"></td>
                            <td><input name="tool" type="text" value="<?= $data['tool'] ?>" class="form-control form-control-sm"></td>
                            <td class="text-center">
                                <button name="update" type="submit" class="btn btn-sm btn-warning">Ubah</button>
                                <button name="delete" type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </td>
                        </form>
                    </tr>
                <?php
                    $no++;
                }
                ?>
            </table>
        </div>
        <a href="cetak-excel-tool.php?pesan=cetak-excel" class="btn btn-sm btn-primary">Export Tool to Excel</a>
        <?php
        if (isset($_POST['update'])) {
            $toolama = $_POST['toolama'];
            $tipelama = $_POST['tipelama'];
            $updateid = $_POST['id'];
            $updatetipe = $_POST['tipe'];
            $updatetool = $_POST['tool'];
            $update = mysqli_query($connect, "UPDATE tool_validator SET tipe='$updatetipe', tool='$updatetool' WHERE id='$updateid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Tool Manager Tab - Update Tool $toolama Menjadi $updatetool Dan Tipe $tipelama Menjadi $updatetipe')");
            echo "Data Berhasil Diupdate";
            header("location:tambahtool.php");
        }
        if (isset($_POST['delete'])) {
            $toolama = $_POST['toolama'];
            $deleteid = $_POST['id'];
            $delete = mysqli_query($connect, "DELETE FROM tool_validator WHERE id='$deleteid'");
            $tgl = date("Y-m-d H:i:s");
            $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Tool Manager Tab - Tool $toolama Dihapus')");
            echo "Data Berhasil Dihapus";
            header("location:tambahtool.php");
        }
        ?>
    </div>
</body>

</html>
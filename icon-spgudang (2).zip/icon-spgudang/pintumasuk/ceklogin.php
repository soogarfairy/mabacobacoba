<?php
// mengaktifkan session php
session_start();

// menghubungkan dengan koneksi
include '../koneksi/conn.php';

// menangkap data yang dikirim dari form
$username = $_POST['username'];
$password = $_POST['password'];

// menyeleksi data admin dengan username dan password yang sesuai
$data = mysqli_query($connect, "SELECT * FROM akun WHERE username='$username' AND password='$password'");
$priv = mysqli_fetch_array($data);

// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);

if ($cek > 0) {
    $_SESSION['username'] = $username;
    $_SESSION['priv'] = $priv['priv'];
    $_SESSION['status'] = "login";
    $tgl = date("Y-m-d H:i:s");
    $log = mysqli_query($connect, "INSERT INTO log VALUES ('','$tgl','$_SESSION[username]','$_SESSION[priv]','Logged In')");
    header("location:administrator/dashboard.php");
} else {
    header("location:index.php?pesan=gagal");
}

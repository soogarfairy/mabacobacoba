<?php
$host     = "localhost";
$user     = "root";
$password = "";
//$password = "mautauaja2020";
$database = "appgudang";
$connect  = mysqli_connect($host, $user, $password, $database);
if (!$connect) {
	die('Gagal terhubung MySQL: ' . mysqli_connect_error());
}
